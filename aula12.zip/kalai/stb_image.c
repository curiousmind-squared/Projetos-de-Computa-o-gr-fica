/*
 * stb_image.cpp
 *
 *  Created on: 4 de nov de 2020
 *      Author: lis
 */


#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

